import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, addDoc, doc, getDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../AuthContext';
import { Division, Classroom } from '../../types';
import { Plus, BookOpen, Users, ArrowRight, LayoutGrid } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import { handleFirestoreError, OperationType } from '../../lib/firebaseUtils';

export default function TeacherDashboard() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [classroom, setClassroom] = useState<Classroom | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!profile?.classroomId) return;

    const fetchClass = async () => {
      try {
        const snap = await getDoc(doc(db, 'classrooms', profile.classroomId!));
        if (snap.exists()) setClassroom({ id: snap.id, ...snap.data() } as Classroom);
      } catch (err) {
        console.error('Error fetching classroom:', err);
      }
    };
    fetchClass();

    const q = query(collection(db, 'divisions'), where('classroomId', '==', profile.classroomId));
    const unsub = onSnapshot(q, (snap) => {
      setDivisions(snap.docs.map(d => ({ id: d.id, ...d.data() } as Division)));
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'divisions');
    });

    return () => unsub();
  }, [profile]);

  const handleCreateDivision = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile?.classroomId || !newName) return;
    setError(null);

    try {
      await addDoc(collection(db, 'divisions'), {
        name: newName,
        classroomId: profile.classroomId,
        teacherId: profile.uid,
        teacherName: profile.name || 'Teacher',
        studentIds: []
      });
      setNewName('');
      setIsCreating(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'divisions');
    }
  };


  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Teacher Dashboard</h1>
          <p className="text-slate-500">{classroom?.name || 'Loading classroom...'}</p>
        </div>
        <button 
          onClick={() => setIsCreating(true)}
          className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
        >
          <Plus className="w-5 h-5" />
          Create Division
        </button>
      </div>

      {isCreating && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 animate-in fade-in slide-in-from-top-4">
          <h2 className="text-lg font-semibold mb-4 text-slate-800">New Division</h2>
          <form onSubmit={handleCreateDivision} className="flex gap-4">
            <input
              type="text"
              required
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Division Name (e.g., G Div)"
              className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-xl font-medium">Create</button>
            <button type="button" onClick={() => setIsCreating(false)} className="text-slate-500 px-4">Cancel</button>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {divisions.map(div => (
          <div key={div.id} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-all group">
            <div className="flex items-center justify-between mb-6">
              <div className="p-3 bg-blue-50 rounded-2xl group-hover:bg-blue-600 transition-colors">
                <LayoutGrid className="w-6 h-6 text-blue-600 group-hover:text-white" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Division</span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">{div.name}</h3>
            <div className="flex flex-col gap-1 text-sm text-slate-500 mb-8">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                {div.studentIds?.length || 0} Students
              </span>
              <span className="text-[10px] text-slate-400 italic">
                {div.teacherId === profile?.uid ? 'Created by you' : `Created by ${div.teacherName || 'another teacher'}`}
              </span>
            </div>
            <button 
              onClick={() => navigate(`/division/${div.id}`)}
              className="w-full flex items-center justify-center gap-2 py-3 bg-slate-50 hover:bg-blue-600 hover:text-white text-slate-600 rounded-2xl font-bold transition-all"
            >
              Open Division
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ))}
        {divisions.length === 0 && (
          <div className="col-span-full py-16 text-center bg-white rounded-3xl border border-dashed border-slate-200">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-slate-50 rounded-full mb-4">
              <BookOpen className="text-slate-300 w-8 h-8" />
            </div>
            <p className="text-slate-400 font-medium">No divisions created yet.</p>
            <p className="text-slate-300 text-sm mt-1">Start by creating your first division.</p>
          </div>
        )}
      </div>
    </div>
  );
}

