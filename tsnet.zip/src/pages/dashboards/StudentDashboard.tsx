import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, getDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../AuthContext';
import { handleFirestoreError, OperationType } from '../../lib/firebaseUtils';
import { Division, Classroom } from '../../types';
import { Users, ArrowRight, LayoutGrid, GraduationCap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function StudentDashboard() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [classroom, setClassroom] = useState<Classroom | null>(null);

  useEffect(() => {
    if (!profile?.classroomId) return;

    const fetchClass = async () => {
      const snap = await getDoc(doc(db, 'classrooms', profile.classroomId!));
      if (snap.exists()) setClassroom({ id: snap.id, ...snap.data() } as Classroom);
    };
    fetchClass();

    // Find divisions where this student is included
    const q = query(collection(db, 'divisions'), where('studentIds', 'array-contains', profile.uid));
    const unsub = onSnapshot(q, (snap) => {
      setDivisions(snap.docs.map(d => ({ id: d.id, ...d.data() } as Division)));
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'divisions');
    });

    return () => unsub();
  }, [profile]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Student Dashboard</h1>
          <p className="text-slate-500">{classroom?.name || 'Loading classroom...'}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {divisions.map(div => (
          <div key={div.id} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-all group">
            <div className="flex items-center justify-between mb-6">
              <div className="p-3 bg-green-50 rounded-2xl group-hover:bg-green-600 transition-colors">
                <LayoutGrid className="w-6 h-6 text-green-600 group-hover:text-white" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Division</span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">{div.name}</h3>
            <div className="flex items-center gap-4 text-sm text-slate-500 mb-8">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                {div.studentIds?.length || 0} Students
              </span>
            </div>
            <button 
              onClick={() => navigate(`/division/${div.id}`)}
              className="w-full flex items-center justify-center gap-2 py-3 bg-slate-50 hover:bg-green-600 hover:text-white text-slate-600 rounded-2xl font-bold transition-all"
            >
              View Division
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ))}
        {divisions.length === 0 && (
          <div className="col-span-full py-16 text-center bg-white rounded-3xl border border-dashed border-slate-200">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-slate-50 rounded-full mb-4">
              <GraduationCap className="text-slate-300 w-8 h-8" />
            </div>
            <p className="text-slate-400 font-medium">You haven't been added to any divisions yet.</p>
            <p className="text-slate-300 text-sm mt-1">Contact your teacher to get added.</p>
          </div>
        )}
      </div>
    </div>
  );
}

