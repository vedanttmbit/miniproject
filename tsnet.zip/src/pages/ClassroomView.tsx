import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, query, where, onSnapshot, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Classroom, UserProfile } from '../types';
import Layout from '../components/Layout';
import { 
  Users, 
  UserPlus, 
  Trash2, 
  Shield, 
  GraduationCap, 
  ArrowLeft,
  MoreVertical,
  Search
} from 'lucide-react';
import { cn } from '../lib/utils';
import { ConfirmModal } from '../components/ConfirmModal';

export default function ClassroomView() {
  const { id } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [classroom, setClassroom] = useState<Classroom | null>(null);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  useEffect(() => {
    if (!id) return;

    const fetchClassroom = async () => {
      const snap = await getDoc(doc(db, 'classrooms', id));
      if (snap.exists()) {
        setClassroom({ id: snap.id, ...snap.data() } as Classroom);
      }
    };
    fetchClassroom();

    const q = query(collection(db, 'users'), where('classroomId', '==', id));
    const unsub = onSnapshot(q, (snap) => {
      setUsers(snap.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile)));
    });

    return () => unsub();
  }, [id]);

  const handleRoleChange = async (userId: string, newRole: 'teacher' | 'student') => {
    await updateDoc(doc(db, 'users', userId), { role: newRole });
  };

  const handleRemoveUser = async (userId: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Remove User',
      message: 'Are you sure you want to remove this user from the classroom?',
      onConfirm: async () => {
        await updateDoc(doc(db, 'users', userId), { 
          classroomId: null,
          role: 'unassigned'
        });
      }
    });
  };

  const teachers = users.filter(u => u.role === 'teacher');
  const students = users.filter(u => u.role === 'student');

  const filteredUsers = (list: UserProfile[]) => 
    list.filter(u => u.name?.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase()));

  if (!classroom) return null;

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-white rounded-xl transition-colors">
            <ArrowLeft className="w-6 h-6 text-slate-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">{classroom.name}</h1>
            <p className="text-slate-500">Manage classroom members and roles</p>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search members..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex gap-4 text-sm">
            <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-xl font-bold">
              <Shield className="w-4 h-4" />
              {teachers.length} Teachers
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-600 rounded-xl font-bold">
              <GraduationCap className="w-4 h-4" />
              {students.length} Students
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Teachers Section */}
          <section className="space-y-4">
            <h2 className="text-lg font-bold flex items-center gap-2 text-slate-800">
              <Shield className="w-5 h-5 text-blue-600" />
              Teachers
            </h2>
            <div className="bg-white rounded-2xl border border-slate-100 divide-y divide-slate-50 overflow-hidden shadow-sm">
              {filteredUsers(teachers).map(user => (
                <UserRow key={user.uid} user={user} onRoleChange={handleRoleChange} onRemove={handleRemoveUser} />
              ))}
              {teachers.length === 0 && <EmptyState text="No teachers assigned." />}
            </div>
          </section>

          {/* Students Section */}
          <section className="space-y-4">
            <h2 className="text-lg font-bold flex items-center gap-2 text-slate-800">
              <GraduationCap className="w-5 h-5 text-green-600" />
              Students
            </h2>
            <div className="bg-white rounded-2xl border border-slate-100 divide-y divide-slate-50 overflow-hidden shadow-sm">
              {filteredUsers(students).map(user => (
                <UserRow key={user.uid} user={user} onRoleChange={handleRoleChange} onRemove={handleRemoveUser} />
              ))}
              {students.length === 0 && <EmptyState text="No students assigned." />}
            </div>
          </section>
        </div>
      </div>
      <ConfirmModal
        isOpen={confirmConfig.isOpen}
        title={confirmConfig.title}
        message={confirmConfig.message}
        onConfirm={confirmConfig.onConfirm}
        onCancel={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
      />
    </Layout>
  );
}

interface UserRowProps {
  user: UserProfile;
  onRoleChange: (userId: string, newRole: 'teacher' | 'student') => Promise<void>;
  onRemove: (userId: string) => Promise<void>;
  key?: string;
}

function UserRow({ user, onRoleChange, onRemove }: UserRowProps) {
  return (
    <div className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors group">
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold uppercase">
          {user.name?.[0] || 'U'}
        </div>
        <div>
          <p className="font-bold text-slate-900">{user.name}</p>
          <p className="text-xs text-slate-500">{user.email}</p>
        </div>
      </div>
      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <select 
          value={user.role}
          onChange={(e) => onRoleChange(user.uid, e.target.value)}
          className="text-xs font-bold bg-slate-100 border-none rounded-lg px-2 py-1 outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="teacher">Teacher</option>
          <option value="student">Student</option>
        </select>
        <button 
          onClick={() => onRemove(user.uid)}
          className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="p-8 text-center text-slate-400 italic text-sm">
      {text}
    </div>
  );
}
