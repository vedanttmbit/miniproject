import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  doc, 
  getDoc, 
  collection, 
  query, 
  where, 
  onSnapshot, 
  updateDoc, 
  arrayUnion, 
  addDoc,
  deleteDoc,
  serverTimestamp,
  getDocs
} from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { handleFirestoreError, OperationType } from '../lib/firebaseUtils';
import { Division, UserProfile, Timetable, AttendanceRecord, Note, Notice, SubjectCriteria } from '../types';
import Layout from '../components/Layout';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell 
} from 'recharts';
import { 
  Users, 
  Calendar, 
  BookOpen, 
  Bell, 
  Plus, 
  Check, 
  X, 
  Link as LinkIcon, 
  FileText,
  ArrowLeft,
  Search,
  UserPlus,
  Eye,
  Pencil,
  Trash2,
  Percent,
  AlertCircle,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { cn } from '../lib/utils';
import { format } from 'date-fns';
import { ConfirmModal } from '../components/ConfirmModal';

type Tab = 'attendance' | 'notes' | 'interact' | 'members' | 'eligibility';

export default function DivisionView() {
  const { id } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();
  
  const [division, setDivision] = useState<Division | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('attendance');
  const [students, setStudents] = useState<UserProfile[]>([]);
  const [allClassroomStudents, setAllClassroomStudents] = useState<UserProfile[]>([]);
  
  // Tab Data
  const [timetable, setTimetable] = useState<Timetable | null>(null);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [subjectCriteria, setSubjectCriteria] = useState<SubjectCriteria[]>([]);

  const isTeacher = profile?.role === 'teacher' || profile?.role === 'admin';

  useEffect(() => {
    if (!id) return;

    const unsubDiv = onSnapshot(doc(db, 'divisions', id), (snap) => {
      if (snap.exists()) {
        const divData = { id: snap.id, ...snap.data() } as Division;
        setDivision(divData);
        
        // Fetch students in this division
        if (divData.studentIds?.length > 0) {
          const q = query(collection(db, 'users'), where('uid', 'in', divData.studentIds));
          getDocs(q).then(sSnap => {
            setStudents(sSnap.docs.map(d => d.data() as UserProfile));
          }).catch(err => {
            handleFirestoreError(err, OperationType.LIST, 'users');
          });
        } else {
          setStudents([]);
        }
      }
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, `divisions/${id}`);
    });

    // Fetch all students in classroom for adding to division (Only for teachers/admins)
    let unsubAll: (() => void) | undefined;
    if (profile?.classroomId && isTeacher) {
      const qAll = query(collection(db, 'users'), where('classroomId', '==', profile.classroomId), where('role', '==', 'student'));
      unsubAll = onSnapshot(qAll, (snap) => {
        setAllClassroomStudents(snap.docs.map(d => d.data() as UserProfile));
      }, (err) => {
        handleFirestoreError(err, OperationType.LIST, 'users');
      });
    }

    // Timetable
    const qTime = query(collection(db, 'timetables'), where('divisionId', '==', id));
    const unsubTime = onSnapshot(qTime, (snap) => {
      if (!snap.empty) setTimetable({ id: snap.docs[0].id, ...snap.docs[0].data() } as Timetable);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'timetables');
    });

    // Attendance
    const qAtt = query(collection(db, 'attendance'), where('divisionId', '==', id));
    const unsubAtt = onSnapshot(qAtt, (snap) => {
      setAttendance(snap.docs.map(d => ({ id: d.id, ...d.data() } as AttendanceRecord)));
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'attendance');
    });

    // Notes
    const qNotes = query(collection(db, 'notes'), where('divisionId', '==', id));
    const unsubNotes = onSnapshot(qNotes, (snap) => {
      setNotes(snap.docs.map(d => ({ id: d.id, ...d.data() } as Note)));
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'notes');
    });

    // Notices
    const qNotices = query(collection(db, 'notices'), where('divisionId', '==', id));
    const unsubNotices = onSnapshot(qNotices, (snap) => {
      setNotices(snap.docs.map(d => ({ id: d.id, ...d.data() } as Notice)));
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'notices');
    });

    // Subject Criteria
    const qCriteria = query(collection(db, 'subjectCriteria'), where('divisionId', '==', id));
    const unsubCriteria = onSnapshot(qCriteria, (snap) => {
      setSubjectCriteria(snap.docs.map(d => ({ id: d.id, ...d.data() } as SubjectCriteria)));
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'subjectCriteria');
    });

    return () => {
      unsubDiv();
      if (unsubAll) unsubAll();
      unsubTime();
      unsubAtt();
      unsubNotes();
      unsubNotices();
      unsubCriteria();
    };
  }, [id, profile]);

  const handleAddStudent = async (studentId: string) => {
    if (!id) return;
    try {
      await updateDoc(doc(db, 'divisions', id), {
        studentIds: arrayUnion(studentId)
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `divisions/${id}`);
    }
  };

  if (!division) return null;

  const tabs: { id: Tab; label: string; icon: any }[] = [
    { id: 'attendance', label: 'Attendance', icon: Calendar },
    { id: 'eligibility', label: 'Eligibility', icon: Percent },
    { id: 'notes', label: 'Smart Notes', icon: BookOpen },
    { id: 'interact', label: 'Interact', icon: Bell },
  ];

  if (isTeacher) {
    tabs.push({ id: 'members', label: 'Members', icon: Users });
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-white rounded-xl transition-colors">
            <ArrowLeft className="w-6 h-6 text-slate-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">{division.name}</h1>
            <p className="text-slate-500">Manage your division activities</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 p-1 bg-slate-100 rounded-2xl w-fit">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all",
                activeTab === tab.id ? "bg-white text-blue-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="mt-8">
          {activeTab === 'attendance' && <AttendanceTab divisionId={id!} isTeacher={isTeacher} students={students} timetable={timetable} attendance={attendance} subjectCriteria={subjectCriteria} />}
          {activeTab === 'eligibility' && <EligibilityTab divisionId={id!} isTeacher={isTeacher} students={students} timetable={timetable} attendance={attendance} subjectCriteria={subjectCriteria} profile={profile} />}
          {activeTab === 'notes' && <NotesTab divisionId={id!} isTeacher={isTeacher} notes={notes} profile={profile} />}
          {activeTab === 'interact' && <InteractTab divisionId={id!} isTeacher={isTeacher} notices={notices} profile={profile} />}
          {activeTab === 'members' && <MembersTab students={students} allClassroomStudents={allClassroomStudents} onAdd={handleAddStudent} />}
        </div>
      </div>
    </Layout>
  );
}

// --- SUB-COMPONENTS ---

function AttendanceTab({ divisionId, isTeacher, students, timetable, attendance, subjectCriteria }: any) {
  const [isCreatingTimetable, setIsCreatingTimetable] = useState(false);
  const [isMarking, setIsMarking] = useState(false);
  const [editingRecordId, setEditingRecordId] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [selectedSubject, setSelectedSubject] = useState('');
  const [presentIds, setPresentIds] = useState<string[]>([]);
  const [addingToDay, setAddingToDay] = useState<string | null>(null);
  const [newSubject, setNewSubject] = useState('');
  const [viewingRecord, setViewingRecord] = useState<any>(null);
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const getDayFromDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return days[date.getDay()];
  };

  const currentDaySubjects = timetable?.schedule?.[getDayFromDate(selectedDate)] || [];

  // Load existing record if it exists for selected date/subject
  useEffect(() => {
    if (isMarking && selectedDate && selectedSubject) {
      const existing = attendance.find((a: any) => a.date === selectedDate && a.subject === selectedSubject);
      if (existing) {
        setEditingRecordId(existing.id);
        setPresentIds(existing.presentStudentIds);
      } else if (!editingRecordId) {
        // Only reset if we weren't already editing a specific record
        setPresentIds([]);
      }
    }
  }, [selectedDate, selectedSubject, isMarking, attendance, editingRecordId]);

  const handleCreateTimetable = async () => {
    try {
      const initialSchedule: any = {};
      days.forEach(d => initialSchedule[d] = []);
      await addDoc(collection(db, 'timetables'), {
        divisionId,
        schedule: initialSchedule
      });
      setIsCreatingTimetable(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'timetables');
    }
  };

  const handleAddSubject = async (day: string) => {
    if (!timetable || !newSubject) return;
    try {
      const newSchedule = { ...timetable.schedule };
      newSchedule[day] = [...(newSchedule[day] || []), newSubject];
      await updateDoc(doc(db, 'timetables', timetable.id), { schedule: newSchedule });
      setNewSubject('');
      setAddingToDay(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `timetables/${timetable.id}`);
    }
  };

  const handleMarkAttendance = async () => {
    if (!selectedSubject) return;
    try {
      const data = {
        divisionId,
        date: selectedDate,
        subject: selectedSubject,
        presentStudentIds: presentIds,
        updatedAt: serverTimestamp()
      };

      if (editingRecordId) {
        await updateDoc(doc(db, 'attendance', editingRecordId), data);
      } else {
        await addDoc(collection(db, 'attendance'), {
          ...data,
          timestamp: serverTimestamp()
        });
      }
      setIsMarking(false);
      setPresentIds([]);
      setSelectedSubject('');
      setEditingRecordId(null);
    } catch (err) {
      handleFirestoreError(err, editingRecordId ? OperationType.UPDATE : OperationType.CREATE, editingRecordId ? `attendance/${editingRecordId}` : 'attendance');
    }
  };

  const handleDeleteAttendance = async (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Attendance Record',
      message: 'Are you sure you want to delete this attendance record? This action cannot be undone.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'attendance', id));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, `attendance/${id}`);
        }
      }
    });
  };

  const chartData = isTeacher ? students.map((student: any) => {
    const studentAttendance = attendance.filter((a: any) => a.presentStudentIds.includes(student.uid));
    const totalClasses = attendance.length;
    const percentage = totalClasses > 0 ? (studentAttendance.length / totalClasses) * 100 : 0;
    return {
      name: student.name,
      percentage: Math.round(percentage),
      attended: studentAttendance.length,
      total: totalClasses
    };
  }).sort((a: any, b: any) => b.percentage - a.percentage) : [];

  return (
    <div className="space-y-8">
      {!timetable && isTeacher && (
        <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200">
          <p className="text-slate-500 mb-4">No timetable found for this division.</p>
          <button onClick={handleCreateTimetable} className="bg-blue-600 text-white px-6 py-2 rounded-xl font-bold">
            Create Timetable
          </button>
        </div>
      )}

      {timetable && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-bold text-slate-800">Weekly Schedule</h3>
            {isTeacher && (
              <button 
                onClick={() => setIsMarking(true)}
                className="bg-green-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shadow-green-100"
              >
                <Check className="w-4 h-4" /> Mark Attendance
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4">
            {days.map(day => (
              <div key={day} className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
                <div className="bg-slate-50 px-4 py-2 border-b border-slate-100 text-center">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">{day}</span>
                </div>
                <div className="p-3 space-y-2 min-h-[150px]">
                  {timetable.schedule[day]?.map((sub: string, i: number) => (
                    <div key={i} className="px-3 py-2 bg-blue-50 text-blue-700 rounded-lg text-xs font-bold">
                      {sub}
                    </div>
                  ))}
                  {isTeacher && (
                    <div className="space-y-2">
                      {addingToDay === day ? (
                        <div className="space-y-2 animate-in fade-in zoom-in-95">
                          <input
                            autoFocus
                            type="text"
                            placeholder="Subject..."
                            value={newSubject}
                            onChange={(e) => setNewSubject(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleAddSubject(day);
                              if (e.key === 'Escape') setAddingToDay(null);
                            }}
                            className="w-full px-2 py-1.5 text-xs bg-white border border-blue-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                          />
                          <div className="flex gap-1">
                            <button 
                              onClick={() => handleAddSubject(day)}
                              className="flex-1 py-1 bg-blue-600 text-white rounded-md text-[10px] font-bold"
                            >
                              Add
                            </button>
                            <button 
                              onClick={() => setAddingToDay(null)}
                              className="flex-1 py-1 bg-slate-100 text-slate-500 rounded-md text-[10px] font-bold"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setAddingToDay(day)}
                          className="w-full py-2 border border-dashed border-slate-200 rounded-lg text-slate-400 hover:text-blue-600 hover:border-blue-200 transition-all text-xs flex items-center justify-center gap-1"
                        >
                          <Plus className="w-3 h-3" /> Add
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Attendance Analytics for Teachers */}
      {isTeacher && chartData.length > 0 && (
        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                <Percent className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900">Attendance Analytics</h3>
                <p className="text-xs text-slate-500 font-medium">Overall attendance percentage per student</p>
              </div>
            </div>
          </div>

          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  angle={-45} 
                  textAnchor="end" 
                  interval={0} 
                  height={80}
                  tick={{ fill: '#64748b', fontSize: 12, fontWeight: 500 }}
                  axisLine={{ stroke: '#e2e8f0' }}
                />
                <YAxis 
                  domain={[0, 100]} 
                  tick={{ fill: '#64748b', fontSize: 12 }}
                  axisLine={{ stroke: '#e2e8f0' }}
                  label={{ value: 'Percentage (%)', angle: -90, position: 'insideLeft', style: { fill: '#64748b', fontWeight: 600, fontSize: 12 } }}
                />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white p-4 rounded-2xl shadow-xl border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
                          <p className="font-bold text-slate-900 mb-1">{data.name}</p>
                          <div className="space-y-1">
                            <p className="text-2xl font-black text-indigo-600">{data.percentage}%</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                              {data.attended} / {data.total} Classes
                            </p>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="percentage" radius={[8, 8, 0, 0]} barSize={40}>
                  {chartData.map((entry: any, index: number) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.percentage >= 75 ? '#4f46e5' : entry.percentage >= 60 ? '#f59e0b' : '#ef4444'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Attendance History */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-800">Attendance History</h3>
        <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-3 font-bold text-slate-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 font-bold text-slate-500 uppercase tracking-wider">Subject</th>
                <th className="px-6 py-3 font-bold text-slate-500 uppercase tracking-wider text-center">Present</th>
                <th className="px-6 py-3 font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {attendance.sort((a, b) => b.date.localeCompare(a.date)).map((rec: any) => (
                <tr key={rec.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 text-slate-600">{rec.date}</td>
                  <td className="px-6 py-4 font-bold text-slate-900">{rec.subject}</td>
                  <td className="px-6 py-4 text-center">
                    <span className="px-3 py-1 bg-green-50 text-green-600 rounded-full font-bold text-xs">
                      {rec.presentStudentIds.length} / {students.length}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right flex justify-end gap-2">
                    <button 
                      onClick={() => setViewingRecord(rec)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      title="View Detailed Attendance"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                    {isTeacher && (
                      <>
                        <button 
                          onClick={() => {
                            setSelectedDate(rec.date);
                            setSelectedSubject(rec.subject);
                            setPresentIds(rec.presentStudentIds);
                            setEditingRecordId(rec.id);
                            setIsMarking(true);
                          }}
                          className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title="Edit Attendance"
                        >
                          <Pencil className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => handleDeleteAttendance(rec.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Attendance"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
              {attendance.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-6 py-8 text-center text-slate-400 italic">No attendance records yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detailed View Modal */}
      {viewingRecord && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold text-slate-900">Attendance Details</h3>
                <p className="text-sm text-slate-500">{viewingRecord.subject} • {viewingRecord.date}</p>
              </div>
              <button onClick={() => setViewingRecord(null)}><X className="w-6 h-6 text-slate-400" /></button>
            </div>
            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {students.map((s: any) => {
                  const isPresent = viewingRecord.presentStudentIds.includes(s.uid);
                  return (
                    <div 
                      key={s.uid}
                      className={cn(
                        "flex items-center justify-between p-4 rounded-2xl border transition-all",
                        isPresent ? "bg-green-50 border-green-100" : "bg-red-50 border-red-100"
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs uppercase",
                          isPresent ? "bg-green-200 text-green-700" : "bg-red-200 text-red-700"
                        )}>
                          {s.name?.[0]}
                        </div>
                        <div>
                          <p className={cn("text-sm font-bold", isPresent ? "text-green-900" : "text-red-900")}>{s.name}</p>
                          <p className={cn("text-[10px]", isPresent ? "text-green-600" : "text-red-600")}>{s.email}</p>
                        </div>
                      </div>
                      <span className={cn(
                        "px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider",
                        isPresent ? "bg-green-200 text-green-700" : "bg-red-200 text-red-700"
                      )}>
                        {isPresent ? 'Present' : 'Absent'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex justify-end">
              <button onClick={() => setViewingRecord(null)} className="px-8 py-3 bg-white border border-slate-200 text-slate-600 rounded-2xl font-bold hover:bg-slate-50 transition-colors">
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Marking Modal */}
      {isMarking && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-xl font-bold text-slate-900">{editingRecordId ? 'Edit' : 'Mark'} Attendance</h3>
              <button onClick={() => {
                setIsMarking(false);
                setEditingRecordId(null);
                setPresentIds([]);
                setSelectedSubject('');
              }}><X className="w-6 h-6 text-slate-400" /></button>
            </div>
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Select Date</label>
                  <input 
                    type="date"
                    value={selectedDate}
                    onChange={(e) => {
                      setSelectedDate(e.target.value);
                      if (!editingRecordId) setSelectedSubject('');
                    }}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Select Subject ({getDayFromDate(selectedDate)})</label>
                  <div className="space-y-2">
                    <select 
                      value={selectedSubject}
                      onChange={(e) => setSelectedSubject(e.target.value)}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Choose a subject...</option>
                      {currentDaySubjects.map((s: string) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                      {/* Fallback: show all subjects from timetable if none for today */}
                      {currentDaySubjects.length === 0 && Array.from(new Set(Object.values(timetable?.schedule || {}).flat() as string[])).map(s => (
                        <option key={s} value={s}>{s} (Not Scheduled)</option>
                      ))}
                    </select>
                    {currentDaySubjects.length === 0 && (
                      <p className="text-[10px] text-amber-600 mt-1 italic">No subjects scheduled for this day in timetable.</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-bold text-slate-700">Students ({presentIds.length} present)</label>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => setPresentIds(students.map((s: any) => s.uid))}
                      className="text-[10px] font-bold text-blue-600 hover:underline"
                    >
                      Mark All Present
                    </button>
                    <button 
                      onClick={() => setPresentIds([])}
                      className="text-[10px] font-bold text-red-600 hover:underline"
                    >
                      Mark All Absent
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {students.map((s: any) => {
                    const isPresent = presentIds.includes(s.uid);
                    return (
                      <div
                        key={s.uid}
                        onClick={() => {
                          if (isPresent) {
                            setPresentIds(prev => prev.filter(id => id !== s.uid));
                          } else {
                            setPresentIds(prev => [...prev, s.uid]);
                          }
                        }}
                        className={cn(
                          "flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer hover:shadow-sm",
                          isPresent ? "bg-green-50 border-green-100" : "bg-red-50 border-red-100"
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs uppercase",
                            isPresent ? "bg-green-200 text-green-700" : "bg-red-200 text-red-700"
                          )}>
                            {s.name?.[0]}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-slate-900">{s.name}</p>
                            <p className="text-[10px] text-slate-500">{s.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className={cn(
                            "w-6 h-6 rounded-full flex items-center justify-center transition-all",
                            isPresent ? "bg-green-600 text-white" : "bg-white border-2 border-slate-200"
                          )}>
                            {isPresent && <Check className="w-4 h-4" />}
                          </div>
                          <span className={cn(
                            "text-[10px] font-bold uppercase tracking-wider",
                            isPresent ? "text-green-600" : "text-red-400"
                          )}>
                            {isPresent ? 'Present' : 'Absent'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex gap-4">
              <button 
                onClick={handleMarkAttendance}
                disabled={!selectedSubject}
                className="flex-1 bg-blue-600 text-white py-3 rounded-2xl font-bold shadow-lg shadow-blue-100 disabled:opacity-50"
              >
                {editingRecordId ? 'Update' : 'Submit'} Attendance
              </button>
              <button onClick={() => {
                setIsMarking(false);
                setEditingRecordId(null);
                setPresentIds([]);
                setSelectedSubject('');
              }} className="px-6 py-3 text-slate-500 font-bold">Cancel</button>
            </div>
          </div>
        </div>
      )}
      <ConfirmModal
        isOpen={confirmConfig.isOpen}
        title={confirmConfig.title}
        message={confirmConfig.message}
        onConfirm={confirmConfig.onConfirm}
        onCancel={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
}

function EligibilityTab({ divisionId, isTeacher, students, timetable, attendance, subjectCriteria, profile }: any) {
  const [editingSubject, setEditingSubject] = useState<string | null>(null);
  const [newMin, setNewMin] = useState<number>(75);
  const [viewingSubject, setViewingSubject] = useState<any>(null);

  const allSubjects = Array.from(new Set(Object.values(timetable?.schedule || {}).flat() as string[]));

  const handleUpdateCriteria = async (subject: string) => {
    try {
      const existing = subjectCriteria.find((c: any) => c.subject === subject);
      if (existing) {
        await updateDoc(doc(db, 'subjectCriteria', existing.id), { minPercentage: newMin });
      } else {
        await addDoc(collection(db, 'subjectCriteria'), {
          divisionId,
          subject,
          minPercentage: newMin
        });
      }
      setEditingSubject(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'subjectCriteria');
    }
  };

  const getStudentStats = (studentId: string) => {
    const stats = allSubjects.map(subject => {
      const subjectAttendance = attendance.filter((a: any) => a.subject === subject);
      const totalClasses = subjectAttendance.length;
      const attendedClasses = subjectAttendance.filter((a: any) => a.presentStudentIds.includes(studentId)).length;
      const percentage = totalClasses > 0 ? (attendedClasses / totalClasses) * 100 : 0;
      const criteria = subjectCriteria.find((c: any) => c.subject === subject)?.minPercentage || 75;
      const isEligible = percentage >= criteria;

      return {
        subject,
        totalClasses,
        attendedClasses,
        percentage,
        criteria,
        isEligible,
        records: subjectAttendance.map((a: any) => ({
          date: a.date,
          isPresent: a.presentStudentIds.includes(studentId)
        })).sort((a: any, b: any) => b.date.localeCompare(a.date))
      };
    });

    const totalClasses = stats.reduce((acc, s) => acc + s.totalClasses, 0);
    const attendedClasses = stats.reduce((acc, s) => acc + s.attendedClasses, 0);
    const totalPercentage = totalClasses > 0 ? (attendedClasses / totalClasses) * 100 : 0;

    return { stats, totalClasses, attendedClasses, totalPercentage };
  };

  if (!isTeacher) {
    const { stats: myStats, totalClasses, attendedClasses, totalPercentage } = getStudentStats(profile.uid);
    
    return (
      <div className="space-y-8">
        {/* Total Attendance Summary */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[2rem] text-white shadow-xl shadow-blue-100">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="space-y-2 text-center md:text-left">
              <h3 className="text-blue-100 font-bold uppercase tracking-widest text-xs">Overall Attendance</h3>
              <p className="text-5xl md:text-6xl font-black">{totalPercentage.toFixed(1)}%</p>
              <p className="text-blue-200 text-sm font-medium">You have attended {attendedClasses} out of {totalClasses} total classes.</p>
            </div>
            
            <div className="flex gap-4">
              <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10 text-center min-w-[100px]">
                <p className="text-2xl font-bold">{attendedClasses}</p>
                <p className="text-[10px] uppercase font-bold text-blue-200 tracking-wider">Attended</p>
              </div>
              <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10 text-center min-w-[100px]">
                <p className="text-2xl font-bold">{totalClasses}</p>
                <p className="text-[10px] uppercase font-bold text-blue-200 tracking-wider">Total</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold text-slate-900">Subject-wise Attendance</h3>
            <p className="text-xs text-slate-500 font-medium">Click on a subject to view detailed history</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myStats.map(stat => (
              <button 
                key={stat.subject} 
                onClick={() => setViewingSubject(stat)}
                className={cn(
                  "p-6 rounded-3xl border transition-all shadow-sm text-left group hover:scale-[1.02] active:scale-[0.98]",
                  stat.isEligible ? "bg-white border-slate-100 hover:border-blue-200" : "bg-red-50 border-red-100 hover:border-red-200"
                )}
              >
                <div className="flex justify-between items-start mb-4">
                  <h4 className="text-lg font-bold text-slate-800 group-hover:text-blue-600 transition-colors">{stat.subject}</h4>
                  {stat.isEligible ? (
                    <CheckCircle2 className="w-6 h-6 text-green-500" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-500" />
                  )}
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-3xl font-black text-slate-900">{stat.percentage.toFixed(1)}%</p>
                      <p className="text-xs text-slate-500">Attendance</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-slate-700">{stat.attendedClasses} / {stat.totalClasses}</p>
                      <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Classes</p>
                    </div>
                  </div>

                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div 
                      className={cn("h-full transition-all duration-500", stat.isEligible ? "bg-green-500" : "bg-red-500")}
                      style={{ width: `${Math.min(stat.percentage, 100)}%` }}
                    />
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-slate-50">
                    <span className="text-xs text-slate-500">Criteria: {stat.criteria}%</span>
                    <span className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                      stat.isEligible ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                    )}>
                      {stat.isEligible ? 'Eligible' : 'Not Eligible'}
                    </span>
                  </div>
                </div>
              </button>
            ))}
            {myStats.length === 0 && (
              <div className="col-span-full py-12 text-center bg-white rounded-3xl border border-dashed border-slate-200">
                <p className="text-slate-500 italic">No subjects or attendance data available yet.</p>
              </div>
            )}
          </div>
        </div>

        {/* Subject Details Modal */}
        {viewingSubject && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
              <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <div>
                  <h3 className="text-2xl font-black text-slate-900">{viewingSubject.subject}</h3>
                  <p className="text-sm text-slate-500 font-medium">Detailed Attendance History</p>
                </div>
                <button 
                  onClick={() => setViewingSubject(null)}
                  className="p-2 hover:bg-white rounded-xl transition-colors text-slate-400"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="p-8 space-y-6 max-h-[60vh] overflow-y-auto">
                <div className="flex gap-4">
                  <div className="flex-1 bg-blue-50 p-4 rounded-2xl text-center">
                    <p className="text-2xl font-black text-blue-700">{viewingSubject.percentage.toFixed(1)}%</p>
                    <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Attendance</p>
                  </div>
                  <div className="flex-1 bg-slate-50 p-4 rounded-2xl text-center">
                    <p className="text-2xl font-black text-slate-700">{viewingSubject.attendedClasses} / {viewingSubject.totalClasses}</p>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Classes</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest px-2">History</h4>
                  <div className="space-y-2">
                    {viewingSubject.records.map((record: any, idx: number) => (
                      <div 
                        key={idx}
                        className={cn(
                          "flex items-center justify-between p-4 rounded-2xl border transition-all",
                          record.isPresent ? "bg-green-50/50 border-green-100" : "bg-red-50/50 border-red-100"
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs",
                            record.isPresent ? "bg-green-200 text-green-700" : "bg-red-200 text-red-700"
                          )}>
                            {record.isPresent ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                          </div>
                          <p className="font-bold text-slate-700">{format(new Date(record.date), 'PPP')}</p>
                        </div>
                        <span className={cn(
                          "px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider",
                          record.isPresent ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                        )}>
                          {record.isPresent ? 'Present' : 'Absent'}
                        </span>
                      </div>
                    ))}
                    {viewingSubject.records.length === 0 && (
                      <p className="text-center text-slate-400 py-8 italic text-sm">No records found for this subject.</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-8 bg-slate-50 flex justify-end">
                <button 
                  onClick={() => setViewingSubject(null)}
                  className="w-full py-4 bg-white border border-slate-200 text-slate-600 rounded-2xl font-bold hover:bg-slate-50 transition-colors shadow-sm"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Criteria Settings for Teachers */}
      <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
            <Percent className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900">Attendance Criteria Settings</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {allSubjects.map(subject => {
            const criteria = subjectCriteria.find((c: any) => c.subject === subject)?.minPercentage || 75;
            const isEditing = editingSubject === subject;

            return (
              <div key={subject} className="p-4 rounded-2xl border border-slate-100 bg-slate-50/50 flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-slate-800">{subject}</p>
                  <p className="text-xs text-slate-500">Min: {criteria}%</p>
                </div>
                {isEditing ? (
                  <div className="flex items-center gap-2">
                    <input 
                      type="number"
                      value={newMin}
                      onChange={(e) => setNewMin(Number(e.target.value))}
                      className="w-16 px-2 py-1 text-sm border rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                      min="0"
                      max="100"
                    />
                    <button onClick={() => handleUpdateCriteria(subject)} className="p-1.5 bg-blue-600 text-white rounded-lg">
                      <Check className="w-4 h-4" />
                    </button>
                    <button onClick={() => setEditingSubject(null)} className="p-1.5 bg-slate-200 text-slate-600 rounded-lg">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => {
                      setEditingSubject(subject);
                      setNewMin(criteria);
                    }}
                    className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })}
          {allSubjects.length === 0 && (
            <p className="col-span-full text-center text-slate-500 py-4 italic">Add subjects to the timetable first to set criteria.</p>
          )}
        </div>
      </div>

      {/* Student Overview for Teachers */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-800">Student Eligibility Overview</h3>
        <div className="bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-4 font-bold text-slate-500 uppercase tracking-wider">Student</th>
                  {allSubjects.map(sub => (
                    <th key={sub} className="px-6 py-4 font-bold text-slate-500 uppercase tracking-wider text-center">{sub}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {students.map((s: any) => {
                  const { stats } = getStudentStats(s.uid);
                  return (
                    <tr key={s.uid} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-xs text-slate-600 uppercase">
                            {s.name?.[0]}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900">{s.name}</p>
                            <p className="text-[10px] text-slate-500">{s.email}</p>
                          </div>
                        </div>
                      </td>
                      {allSubjects.map(sub => {
                        const stat = stats.find(st => st.subject === sub);
                        if (!stat) return <td key={sub} className="px-6 py-4 text-center text-slate-300">-</td>;
                        return (
                          <td key={sub} className="px-6 py-4 text-center">
                            <div className={cn(
                              "inline-flex flex-col items-center px-3 py-1.5 rounded-xl",
                              stat.isEligible ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                            )}>
                              <span className="font-black text-xs">{stat.percentage.toFixed(0)}%</span>
                              <span className="text-[8px] uppercase tracking-tighter font-bold">{stat.isEligible ? 'Eligible' : 'Low'}</span>
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

function NotesTab({ divisionId, isTeacher, notes, profile }: any) {
  const [isAdding, setIsAdding] = useState(false);
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [link, setLink] = useState('');
  const [links, setLinks] = useState<string[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const finalLinks = link ? [...links, link] : links;
      await addDoc(collection(db, 'notes'), {
        divisionId,
        title,
        subject,
        links: finalLinks,
        teacherId: profile?.uid,
        teacherName: profile?.name || 'Teacher',
        timestamp: new Date().toISOString()
      });
      setIsAdding(false);
      setTitle('');
      setSubject('');
      setLink('');
      setLinks([]);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'notes');
    }
  };

  const handleUpdateNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingId) return;
    try {
      const finalLinks = link ? [...links, link] : links;
      await updateDoc(doc(db, 'notes', editingId), {
        title,
        subject,
        links: finalLinks,
        updatedAt: new Date().toISOString()
      });
      setEditingId(null);
      setTitle('');
      setSubject('');
      setLink('');
      setLinks([]);
      setIsAdding(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `notes/${editingId}`);
    }
  };

  const handleDeleteNote = async (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Note',
      message: 'Are you sure you want to delete this note? This action cannot be undone.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'notes', id));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, `notes/${id}`);
        }
      }
    });
  };

  const startEdit = (note: any) => {
    setEditingId(note.id);
    setTitle(note.title);
    setSubject(note.subject);
    setLinks(note.links || []);
    setIsAdding(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold text-slate-800">Smart Notes</h3>
        {isTeacher && (
          <button onClick={() => setIsAdding(true)} className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2">
            <Plus className="w-4 h-4" /> Add Note
          </button>
        )}
      </div>

      {isAdding && (
        <form onSubmit={editingId ? handleUpdateNote : handleAddNote} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4 animate-in fade-in slide-in-from-top-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="text" placeholder="Subject" required value={subject} onChange={(e) => setSubject(e.target.value)} className="px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none" />
            <input type="text" placeholder="Title" required value={title} onChange={(e) => setTitle(e.target.value)} className="px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none" />
          </div>
          <div className="flex gap-2">
            <input type="url" placeholder="Add Link (https://...)" value={link} onChange={(e) => setLink(e.target.value)} className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none" />
            <button type="button" onClick={() => { if(link) { setLinks([...links, link]); setLink(''); } }} className="bg-slate-100 text-slate-600 px-4 rounded-xl font-bold">Add Link</button>
          </div>
          {links.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {links.map((l, i) => (
                <div key={i} className="flex items-center gap-1 px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-xs font-bold">
                  <span className="truncate max-w-[150px]">{l}</span>
                  <button type="button" onClick={() => setLinks(links.filter((_, idx) => idx !== i))}><X className="w-3 h-3" /></button>
                </div>
              ))}
            </div>
          )}
          <div className="flex gap-4 pt-2">
            <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-xl font-bold">
              {editingId ? 'Update Note' : 'Save Note'}
            </button>
            <button 
              type="button" 
              onClick={() => {
                setIsAdding(false);
                setEditingId(null);
                setTitle('');
                setSubject('');
                setLinks([]);
              }} 
              className="text-slate-500 font-bold"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {notes.map((note: any) => (
          <div key={note.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all group relative flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <span className="px-3 py-1 bg-slate-100 text-slate-600 text-[10px] font-bold uppercase tracking-widest rounded-full">{note.subject}</span>
              <div className="flex items-center gap-2">
                {isTeacher && (
                  <div className="flex gap-1">
                    <button onClick={() => startEdit(note)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => handleDeleteNote(note.id)} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
                  </div>
                )}
                <FileText className="w-5 h-5 text-slate-300 group-hover:text-blue-600 transition-colors" />
              </div>
            </div>
            <h4 className="text-lg font-bold text-slate-900 mb-4">{note.title}</h4>
            <div className="space-y-2 mb-4 flex-1">
              {note.links?.map((l: string, i: number) => (
                <a key={i} href={l} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-blue-600 hover:underline">
                  <LinkIcon className="w-3 h-3" />
                  <span className="truncate">Resource {i + 1}</span>
                </a>
              ))}
            </div>
            <div className="pt-4 border-t border-slate-50 flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              <span>{note.teacherName || 'Teacher'}</span>
              <span>{new Date(note.timestamp).toLocaleDateString()}</span>
            </div>
          </div>
        ))}
        {notes.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-400 italic">No notes shared yet.</div>
        )}
      </div>
      <ConfirmModal
        isOpen={confirmConfig.isOpen}
        title={confirmConfig.title}
        message={confirmConfig.message}
        onConfirm={confirmConfig.onConfirm}
        onCancel={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
}

function InteractTab({ divisionId, isTeacher, notices, profile }: any) {
  const [isAdding, setIsAdding] = useState(false);
  const [content, setContent] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const handleAddNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'notices'), {
        divisionId,
        content,
        teacherId: profile?.uid,
        teacherName: profile?.name || 'Teacher',
        timestamp: new Date().toISOString()
      });
      setIsAdding(false);
      setContent('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'notices');
    }
  };

  const handleUpdateNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingId) return;
    try {
      await updateDoc(doc(db, 'notices', editingId), {
        content: editContent,
        updatedAt: new Date().toISOString()
      });
      setEditingId(null);
      setEditContent('');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `notices/${editingId}`);
    }
  };

  const handleDeleteNotice = async (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Notice',
      message: 'Are you sure you want to delete this notice? This action cannot be undone.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'notices', id));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, `notices/${id}`);
        }
      }
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold text-slate-800">Notices & Announcements</h3>
        {isTeacher && (
          <button onClick={() => setIsAdding(true)} className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2">
            <Plus className="w-4 h-4" /> Post Notice
          </button>
        )}
      </div>

      {isAdding && (
        <form onSubmit={handleAddNotice} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4 animate-in fade-in slide-in-from-top-4">
          <textarea 
            required 
            value={content} 
            onChange={(e) => setContent(e.target.value)} 
            placeholder="Write your announcement here..." 
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl outline-none min-h-[120px] resize-none"
          />
          <div className="flex gap-4">
            <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-xl font-bold">Post Announcement</button>
            <button type="button" onClick={() => setIsAdding(false)} className="text-slate-500 font-bold">Cancel</button>
          </div>
        </form>
      )}

      <div className="space-y-4">
        {notices.sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map((notice: any) => (
          <div key={notice.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-1 h-full bg-blue-600"></div>
            
            {editingId === notice.id ? (
              <form onSubmit={handleUpdateNotice} className="space-y-4">
                <textarea 
                  required 
                  value={editContent} 
                  onChange={(e) => setEditContent(e.target.value)} 
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl outline-none min-h-[100px] resize-none"
                />
                <div className="flex gap-2">
                  <button type="submit" className="bg-blue-600 text-white px-4 py-1.5 rounded-lg text-xs font-bold">Update</button>
                  <button type="button" onClick={() => setEditingId(null)} className="text-slate-500 text-xs font-bold">Cancel</button>
                </div>
              </form>
            ) : (
              <>
                <div className="flex justify-between items-start mb-4">
                  <p className="text-slate-700 leading-relaxed whitespace-pre-wrap flex-1">{notice.content}</p>
                  {isTeacher && (
                    <div className="flex gap-1 ml-4">
                      <button 
                        onClick={() => {
                          setEditingId(notice.id);
                          setEditContent(notice.content);
                        }}
                        className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDeleteNotice(notice.id)}
                        className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
                <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  <span>Posted by {notice.teacherName || 'Teacher'} {notice.updatedAt && '(Edited)'}</span>
                  <span>{new Date(notice.timestamp).toLocaleString()}</span>
                </div>
              </>
            )}
          </div>
        ))}
        {notices.length === 0 && (
          <div className="py-12 text-center text-slate-400 italic">No announcements yet.</div>
        )}
      </div>
      <ConfirmModal
        isOpen={confirmConfig.isOpen}
        title={confirmConfig.title}
        message={confirmConfig.message}
        onConfirm={confirmConfig.onConfirm}
        onCancel={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
}

function MembersTab({ students, allClassroomStudents, onAdd }: any) {
  const [searchTerm, setSearchTerm] = useState('');

  const unassignedStudents = allClassroomStudents.filter((s: any) => !students.find((curr: any) => curr.uid === s.uid));
  const filteredUnassigned = unassignedStudents.filter((s: any) => s.name?.toLowerCase().includes(searchTerm.toLowerCase()) || s.email.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-600" />
          Division Members ({students.length})
        </h3>
        <div className="bg-white rounded-3xl border border-slate-100 divide-y divide-slate-50 overflow-hidden shadow-sm">
          {students.map((s: any) => (
            <div key={s.uid} className="p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold uppercase">{s.name?.[0]}</div>
              <div>
                <p className="font-bold text-slate-900">{s.name}</p>
                <p className="text-xs text-slate-500">{s.email}</p>
              </div>
            </div>
          ))}
          {students.length === 0 && <div className="p-8 text-center text-slate-400 italic">No members yet.</div>}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <UserPlus className="w-5 h-5 text-green-600" />
          Add Students
        </h3>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search classroom students..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            />
          </div>
          <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
            {filteredUnassigned.map((s: any) => (
              <div key={s.uid} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100 group">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-slate-400 font-bold text-xs uppercase">{s.name?.[0]}</div>
                  <div>
                    <p className="text-sm font-bold text-slate-900">{s.name}</p>
                    <p className="text-[10px] text-slate-500">{s.email}</p>
                  </div>
                </div>
                <button 
                  onClick={() => onAdd(s.uid)}
                  className="p-2 bg-white text-blue-600 rounded-xl shadow-sm opacity-0 group-hover:opacity-100 transition-all hover:bg-blue-600 hover:text-white"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            ))}
            {filteredUnassigned.length === 0 && <p className="text-center py-4 text-slate-400 text-sm italic">No more students to add.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
