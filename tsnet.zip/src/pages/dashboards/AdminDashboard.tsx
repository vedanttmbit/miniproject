import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, addDoc, doc, updateDoc, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../AuthContext';
import { Classroom, JoinRequest, UserProfile } from '../../types';
import { Plus, Users, School, Check, X, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function AdminDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [classrooms, setClassrooms] = useState<Classroom[]>([]);
  const [requests, setRequests] = useState<JoinRequest[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newClassName, setNewClassName] = useState('');

  useEffect(() => {
    if (!user) return;

    const qClass = query(collection(db, 'classrooms'), where('adminId', '==', user.uid));
    const unsubClass = onSnapshot(qClass, (snap) => {
      setClassrooms(snap.docs.map(d => ({ id: d.id, ...d.data() } as Classroom)));
    });

    const qReq = query(collection(db, 'joinRequests'), where('status', '==', 'pending'));
    const unsubReq = onSnapshot(qReq, async (snap) => {
      const reqData = await Promise.all(snap.docs.map(async (d) => {
        const data = d.data() as JoinRequest;
        const userSnap = await getDocs(query(collection(db, 'users'), where('uid', '==', data.userId)));
        const userData = userSnap.docs[0]?.data() as UserProfile;
        return { 
          ...data, 
          id: d.id, 
          userName: userData?.name, 
          userEmail: userData?.email,
          userBio: userData?.bio
        };
      }));
      setRequests(reqData);
    });

    return () => {
      unsubClass();
      unsubReq();
    };
  }, [user]);

  const handleCreateClassroom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newClassName) return;
    
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    await addDoc(collection(db, 'classrooms'), {
      name: newClassName,
      code,
      adminId: user.uid,
      status: 'open',
      createdAt: new Date().toISOString()
    });
    setNewClassName('');
    setIsCreating(false);
  };

  const handleRequest = async (requestId: string, userId: string, classroomId: string, status: 'accepted' | 'rejected') => {
    await updateDoc(doc(db, 'joinRequests', requestId), { status });
    if (status === 'accepted') {
      // For now, default to student, admin can change later in classroom management
      await updateDoc(doc(db, 'users', userId), { 
        role: 'student',
        classroomId 
      });
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Admin Dashboard</h1>
          <p className="text-slate-500">Manage classrooms and join requests</p>
        </div>
        <button 
          onClick={() => setIsCreating(true)}
          className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
        >
          <Plus className="w-5 h-5" />
          Create Classroom
        </button>
      </div>

      {isCreating && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 animate-in fade-in slide-in-from-top-4">
          <h2 className="text-lg font-semibold mb-4">New Classroom</h2>
          <form onSubmit={handleCreateClassroom} className="flex gap-4">
            <input
              type="text"
              required
              value={newClassName}
              onChange={(e) => setNewClassName(e.target.value)}
              placeholder="Classroom Name (e.g., Computer Science)"
              className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-xl font-medium">Create</button>
            <button type="button" onClick={() => setIsCreating(false)} className="text-slate-500 px-4">Cancel</button>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Classrooms List */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <School className="w-5 h-5 text-blue-600" />
            Active Classrooms
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {classrooms.map(cls => (
              <div key={cls.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-bold text-slate-900 text-lg">{cls.name}</h3>
                  <span className="px-2 py-1 bg-green-50 text-green-600 text-xs font-bold rounded-lg uppercase">{cls.status}</span>
                </div>
                <div className="flex items-center justify-between text-sm text-slate-500 mb-6">
                  <span>Code: <span className="font-mono font-bold text-slate-900">{cls.code}</span></span>
                </div>
                <button 
                  onClick={() => navigate(`/classroom/${cls.id}`)}
                  className="w-full flex items-center justify-center gap-2 py-2 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-xl font-medium transition-colors"
                >
                  Manage Classroom
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ))}
            {classrooms.length === 0 && (
              <div className="col-span-full py-12 text-center bg-white rounded-2xl border border-dashed border-slate-200">
                <p className="text-slate-400">No classrooms created yet.</p>
              </div>
            )}
          </div>
        </div>

        {/* Join Requests */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            Pending Requests ({requests.length})
          </h2>
          <div className="space-y-4">
            {requests.map(req => (
              <div key={req.id} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
                <div className="mb-3">
                  <p className="font-bold text-slate-900">{req.userName || 'Unknown User'}</p>
                  <p className="text-xs text-slate-500">{req.userEmail}</p>
                </div>
                <p className="text-sm text-slate-600 mb-4 line-clamp-2 italic">"{req.userBio}"</p>
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleRequest(req.id, req.userId, req.classroomId, 'accepted')}
                    className="flex-1 flex items-center justify-center gap-1 py-2 bg-green-600 text-white rounded-xl text-sm font-medium hover:bg-green-700 transition-colors"
                  >
                    <Check className="w-4 h-4" /> Accept
                  </button>
                  <button 
                    onClick={() => handleRequest(req.id, req.userId, req.classroomId, 'rejected')}
                    className="flex-1 flex items-center justify-center gap-1 py-2 bg-red-50 text-red-600 rounded-xl text-sm font-medium hover:bg-red-100 transition-colors"
                  >
                    <X className="w-4 h-4" /> Reject
                  </button>
                </div>
              </div>
            ))}
            {requests.length === 0 && (
              <div className="py-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                <p className="text-slate-400 text-sm">No pending requests.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
