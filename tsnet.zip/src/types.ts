export type UserRole = 'admin' | 'teacher' | 'student' | 'unassigned';

export interface UserProfile {
  uid: string;
  email: string;
  name?: string;
  bio?: string;
  role: UserRole;
  classroomId?: string;
  createdAt: string;
}

export interface Classroom {
  id: string;
  name: string;
  code: string;
  adminId: string;
  status: 'open' | 'closed';
  createdAt: string;
}

export interface JoinRequest {
  id: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  userBio?: string;
  classroomId: string;
  status: 'pending' | 'accepted' | 'rejected';
  timestamp: string;
}

export interface Division {
  id: string;
  classroomId: string;
  name: string;
  teacherId: string;
  studentIds: string[];
}

export interface Timetable {
  id: string;
  divisionId: string;
  schedule: Record<string, string[]>; // Day -> Subjects
}

export interface AttendanceRecord {
  id: string;
  divisionId: string;
  date: string;
  subject: string;
  presentStudentIds: string[];
}

export interface Note {
  id: string;
  divisionId: string;
  subject: string;
  title: string;
  links: string[];
  timestamp: string;
}

export interface Notice {
  id: string;
  divisionId: string;
  content: string;
  timestamp: string;
  teacherId?: string;
  teacherName?: string;
  updatedAt?: string;
}

export interface SubjectCriteria {
  id: string;
  divisionId: string;
  subject: string;
  minPercentage: number;
}
