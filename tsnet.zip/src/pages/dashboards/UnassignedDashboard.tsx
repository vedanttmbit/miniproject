import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, addDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../AuthContext';
import { handleFirestoreError, OperationType } from '../../lib/firebaseUtils';
import { Classroom } from '../../types';
import { Search, Send, Clock, CheckCircle, XCircle, School } from 'lucide-react';
import { cn } from '../../lib/utils';

export default function UnassignedDashboard() {
  const { user, profile } = useAuth();
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [myRequests, setMyRequests] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'joinRequests'), where('userId', '==', user.uid));
    const unsub = onSnapshot(q, (snap) => {
      setMyRequests(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'joinRequests');
    });
    return () => unsub();
  }, [user]);

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !code) return;
    setLoading(true);
    setMessage(null);

    try {
      const q = query(collection(db, 'classrooms'), where('code', '==', code.toUpperCase()));
      const snap = await getDocs(q);

      if (snap.empty) {
        setMessage({ type: 'error', text: 'Invalid classroom code.' });
        return;
      }

      const classroom = snap.docs[0];
      
      // Check if already requested
      const existingReq = myRequests.find(r => r.classroomId === classroom.id && r.status === 'pending');
      if (existingReq) {
        setMessage({ type: 'error', text: 'You already have a pending request for this classroom.' });
        return;
      }

      await addDoc(collection(db, 'joinRequests'), {
        userId: user.uid,
        classroomId: classroom.id,
        status: 'pending',
        timestamp: new Date().toISOString()
      });

      setMessage({ type: 'success', text: 'Join request sent! Wait for HOD approval.' });
      setCode('');
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to send request.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white p-8 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100 text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-50 rounded-full mb-6">
          <School className="text-blue-600 w-10 h-10" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Welcome to TsNet, {profile?.name}!</h1>
        <p className="text-slate-500 max-w-md mx-auto mb-8">
          You are currently unassigned. Please enter a classroom code provided by your HOD to join a network.
        </p>

        <form onSubmit={handleJoin} className="max-w-md mx-auto relative">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              required
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Enter Classroom Code"
              className="w-full pl-12 pr-32 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-lg tracking-widest uppercase"
            />
            <button
              type="submit"
              disabled={loading}
              className="absolute right-2 top-2 bottom-2 bg-blue-600 text-white px-6 rounded-xl font-semibold hover:bg-blue-700 transition-all disabled:opacity-50 flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              Join
            </button>
          </div>
        </form>

        {message && (
          <div className={cn(
            "mt-6 p-4 rounded-xl text-sm font-medium animate-in fade-in slide-in-from-top-2",
            message.type === 'success' ? "bg-green-50 text-green-700 border border-green-100" : "bg-red-50 text-red-700 border border-red-100"
          )}>
            {message.text}
          </div>
        )}
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <Clock className="w-6 h-6 text-blue-600" />
          Your Join Requests
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {myRequests.map(req => (
            <div key={req.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400 font-medium uppercase tracking-wider mb-1">Request ID: {req.id.slice(0, 8)}</p>
                <p className="text-slate-500 text-sm">{new Date(req.timestamp).toLocaleDateString()}</p>
              </div>
              <div className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold uppercase tracking-wide",
                req.status === 'pending' ? "bg-amber-50 text-amber-600" : 
                req.status === 'accepted' ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"
              )}>
                {req.status === 'pending' && <Clock className="w-4 h-4" />}
                {req.status === 'accepted' && <CheckCircle className="w-4 h-4" />}
                {req.status === 'rejected' && <XCircle className="w-4 h-4" />}
                {req.status}
              </div>
            </div>
          ))}
          {myRequests.length === 0 && (
            <div className="col-span-full py-12 text-center bg-slate-50 rounded-3xl border border-dashed border-slate-200">
              <p className="text-slate-400">No requests sent yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
